﻿namespace LabExam
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.txtp = new System.Windows.Forms.TextBox();
            this.txtcc = new System.Windows.Forms.TextBox();
            this.txtsq = new System.Windows.Forms.TextBox();
            this.txtsp = new System.Windows.Forms.TextBox();
            this.txtse = new System.Windows.Forms.TextBox();
            this.txtsee = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.lbltotal = new System.Windows.Forms.Label();
            this.lblsee = new System.Windows.Forms.Label();
            this.lblse = new System.Windows.Forms.Label();
            this.lblsp = new System.Windows.Forms.Label();
            this.lblsq = new System.Windows.Forms.Label();
            this.lblcc = new System.Windows.Forms.Label();
            this.lblp = new System.Windows.Forms.Label();
            this.lblpersee = new System.Windows.Forms.Label();
            this.lblperse = new System.Windows.Forms.Label();
            this.lblpersp = new System.Windows.Forms.Label();
            this.lblpersq = new System.Windows.Forms.Label();
            this.lblpercc = new System.Windows.Forms.Label();
            this.lblperp = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.lblgpa = new System.Windows.Forms.Label();
            this.lblpertotal = new System.Windows.Forms.Label();
            this.lblgrade = new System.Windows.Forms.Label();
            this.lblpercentage = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Old English Text MT", 24F);
            this.label1.Location = new System.Drawing.Point(232, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(527, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Usman Institute of Technology";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Old English Text MT", 24F);
            this.label2.Location = new System.Drawing.Point(442, 9);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 48);
            this.label2.TabIndex = 1;
            this.label2.Text = "UIT";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(425, 163);
            this.label3.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(155, 32);
            this.label3.TabIndex = 2;
            this.label3.Text = "Marksheet";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(352, 116);
            this.label4.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(295, 35);
            this.label4.TabIndex = 3;
            this.label4.Text = "Semester Examination";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(26, 241);
            this.label5.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(75, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Name:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(26, 296);
            this.label6.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(166, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "Registration No:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(26, 351);
            this.label7.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(74, 25);
            this.label7.TabIndex = 6;
            this.label7.Text = "Batch:";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(194, 296);
            this.textBox1.Margin = new System.Windows.Forms.Padding(5);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(277, 30);
            this.textBox1.TabIndex = 7;
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(194, 241);
            this.textBox2.Margin = new System.Windows.Forms.Padding(5);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(277, 30);
            this.textBox2.TabIndex = 8;
            // 
            // textBox3
            // 
            this.textBox3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.Location = new System.Drawing.Point(194, 351);
            this.textBox3.Margin = new System.Windows.Forms.Padding(5);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(277, 30);
            this.textBox3.TabIndex = 9;
            // 
            // textBox5
            // 
            this.textBox5.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox5.Location = new System.Drawing.Point(675, 240);
            this.textBox5.Margin = new System.Windows.Forms.Padding(5);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(277, 30);
            this.textBox5.TabIndex = 14;
            // 
            // textBox6
            // 
            this.textBox6.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox6.Location = new System.Drawing.Point(675, 295);
            this.textBox6.Margin = new System.Windows.Forms.Padding(5);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(277, 30);
            this.textBox6.TabIndex = 13;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(529, 296);
            this.label9.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(130, 25);
            this.label9.TabIndex = 11;
            this.label9.Text = "Department:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(529, 241);
            this.label10.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(143, 25);
            this.label10.TabIndex = 10;
            this.label10.Text = "Father Name:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(25, 412);
            this.label8.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(507, 32);
            this.label8.TabIndex = 12;
            this.label8.Text = "FALL Semester 2024 (7th Semester)";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(26, 479);
            this.label11.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(104, 25);
            this.label11.TabIndex = 15;
            this.label11.Text = "Crs Code";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(149, 479);
            this.label12.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(130, 25);
            this.label12.TabIndex = 16;
            this.label12.Text = "Course Title";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(567, 479);
            this.label13.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(118, 25);
            this.label13.TabIndex = 18;
            this.label13.Text = "Obt. Marks";
            this.label13.Click += new System.EventHandler(this.label13_Click);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(410, 479);
            this.label14.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(126, 25);
            this.label14.TabIndex = 17;
            this.label14.Text = "Total Marks";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(819, 479);
            this.label15.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(122, 25);
            this.label15.TabIndex = 20;
            this.label15.Text = "Percentage";
            this.label15.Click += new System.EventHandler(this.label15_Click);
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(722, 479);
            this.label16.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(71, 25);
            this.label16.TabIndex = 19;
            this.label16.Text = "Grade";
            this.label16.Click += new System.EventHandler(this.label16_Click);
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(44, 522);
            this.label17.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(71, 22);
            this.label17.TabIndex = 21;
            this.label17.Text = "CS-112";
            this.label17.Click += new System.EventHandler(this.label17_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(44, 554);
            this.label18.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(71, 22);
            this.label18.TabIndex = 22;
            this.label18.Text = "CS-419";
            this.label18.Click += new System.EventHandler(this.label18_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(44, 617);
            this.label19.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(70, 22);
            this.label19.TabIndex = 24;
            this.label19.Text = "SE-111";
            this.label19.Click += new System.EventHandler(this.label19_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(44, 587);
            this.label20.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(71, 22);
            this.label20.TabIndex = 23;
            this.label20.Text = "CS-451";
            this.label20.Click += new System.EventHandler(this.label20_Click);
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(44, 650);
            this.label21.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(70, 22);
            this.label21.TabIndex = 25;
            this.label21.Text = "SE-211";
            this.label21.Click += new System.EventHandler(this.label21_Click);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(44, 682);
            this.label22.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(70, 22);
            this.label22.TabIndex = 26;
            this.label22.Text = "SE-311";
            this.label22.Click += new System.EventHandler(this.label22_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(163, 682);
            this.label23.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(173, 22);
            this.label23.TabIndex = 32;
            this.label23.Text = "Software Economics";
            this.label23.Click += new System.EventHandler(this.label23_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(163, 650);
            this.label24.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(182, 22);
            this.label24.TabIndex = 31;
            this.label24.Text = "Software Engineering";
            this.label24.Click += new System.EventHandler(this.label24_Click);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(163, 617);
            this.label25.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(142, 22);
            this.label25.TabIndex = 30;
            this.label25.Text = "Software Project";
            this.label25.Click += new System.EventHandler(this.label25_Click);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(163, 587);
            this.label26.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(142, 22);
            this.label26.TabIndex = 29;
            this.label26.Text = "Software Quality";
            this.label26.Click += new System.EventHandler(this.label26_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.Location = new System.Drawing.Point(163, 554);
            this.label27.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(148, 22);
            this.label27.TabIndex = 28;
            this.label27.Text = "Cloud Computing";
            this.label27.Click += new System.EventHandler(this.label27_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.Location = new System.Drawing.Point(163, 522);
            this.label28.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(116, 22);
            this.label28.TabIndex = 27;
            this.label28.Text = "Programming";
            this.label28.Click += new System.EventHandler(this.label28_Click);
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(457, 682);
            this.label29.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(40, 22);
            this.label29.TabIndex = 38;
            this.label29.Text = "100";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(457, 650);
            this.label30.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(40, 22);
            this.label30.TabIndex = 37;
            this.label30.Text = "100";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(457, 617);
            this.label31.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(40, 22);
            this.label31.TabIndex = 36;
            this.label31.Text = "100";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(457, 587);
            this.label32.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(40, 22);
            this.label32.TabIndex = 35;
            this.label32.Text = "100";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(457, 554);
            this.label33.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(40, 22);
            this.label33.TabIndex = 34;
            this.label33.Text = "100";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(457, 522);
            this.label34.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(40, 22);
            this.label34.TabIndex = 33;
            this.label34.Text = "100";
            // 
            // txtp
            // 
            this.txtp.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtp.Location = new System.Drawing.Point(595, 522);
            this.txtp.Margin = new System.Windows.Forms.Padding(5);
            this.txtp.Name = "txtp";
            this.txtp.Size = new System.Drawing.Size(52, 28);
            this.txtp.TabIndex = 39;
            this.txtp.TextChanged += new System.EventHandler(this.txtp_TextChanged);
            // 
            // txtcc
            // 
            this.txtcc.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtcc.Location = new System.Drawing.Point(595, 554);
            this.txtcc.Margin = new System.Windows.Forms.Padding(5);
            this.txtcc.Name = "txtcc";
            this.txtcc.Size = new System.Drawing.Size(52, 28);
            this.txtcc.TabIndex = 40;
            this.txtcc.TextChanged += new System.EventHandler(this.txtcc_TextChanged);
            // 
            // txtsq
            // 
            this.txtsq.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsq.Location = new System.Drawing.Point(595, 587);
            this.txtsq.Margin = new System.Windows.Forms.Padding(5);
            this.txtsq.Name = "txtsq";
            this.txtsq.Size = new System.Drawing.Size(52, 28);
            this.txtsq.TabIndex = 41;
            this.txtsq.TextChanged += new System.EventHandler(this.txtsq_TextChanged);
            // 
            // txtsp
            // 
            this.txtsp.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsp.Location = new System.Drawing.Point(595, 617);
            this.txtsp.Margin = new System.Windows.Forms.Padding(5);
            this.txtsp.Name = "txtsp";
            this.txtsp.Size = new System.Drawing.Size(52, 28);
            this.txtsp.TabIndex = 42;
            this.txtsp.TextChanged += new System.EventHandler(this.txtsp_TextChanged);
            // 
            // txtse
            // 
            this.txtse.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtse.Location = new System.Drawing.Point(595, 650);
            this.txtse.Margin = new System.Windows.Forms.Padding(5);
            this.txtse.Name = "txtse";
            this.txtse.Size = new System.Drawing.Size(52, 28);
            this.txtse.TabIndex = 43;
            this.txtse.TextChanged += new System.EventHandler(this.txtse_TextChanged);
            // 
            // txtsee
            // 
            this.txtsee.Font = new System.Drawing.Font("Times New Roman", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtsee.Location = new System.Drawing.Point(595, 682);
            this.txtsee.Margin = new System.Windows.Forms.Padding(5);
            this.txtsee.Name = "txtsee";
            this.txtsee.Size = new System.Drawing.Size(52, 28);
            this.txtsee.TabIndex = 44;
            this.txtsee.TextChanged += new System.EventHandler(this.txtsee_TextChanged);
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.Location = new System.Drawing.Point(346, 718);
            this.label35.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(62, 22);
            this.label35.TabIndex = 45;
            this.label35.Text = "Total.";
            // 
            // lbltotal
            // 
            this.lbltotal.AutoSize = true;
            this.lbltotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbltotal.Location = new System.Drawing.Point(457, 718);
            this.lbltotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lbltotal.Name = "lbltotal";
            this.lbltotal.Size = new System.Drawing.Size(43, 22);
            this.lbltotal.TabIndex = 46;
            this.lbltotal.Text = "600";
            // 
            // lblsee
            // 
            this.lblsee.AutoSize = true;
            this.lblsee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsee.Location = new System.Drawing.Point(736, 682);
            this.lblsee.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsee.Name = "lblsee";
            this.lblsee.Size = new System.Drawing.Size(0, 22);
            this.lblsee.TabIndex = 52;
            this.lblsee.Click += new System.EventHandler(this.label37_Click);
            // 
            // lblse
            // 
            this.lblse.AutoSize = true;
            this.lblse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblse.Location = new System.Drawing.Point(736, 650);
            this.lblse.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblse.Name = "lblse";
            this.lblse.Size = new System.Drawing.Size(0, 22);
            this.lblse.TabIndex = 51;
            this.lblse.Click += new System.EventHandler(this.lblse_Click);
            // 
            // lblsp
            // 
            this.lblsp.AutoSize = true;
            this.lblsp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsp.Location = new System.Drawing.Point(736, 617);
            this.lblsp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsp.Name = "lblsp";
            this.lblsp.Size = new System.Drawing.Size(0, 22);
            this.lblsp.TabIndex = 50;
            this.lblsp.Click += new System.EventHandler(this.lblsp_Click);
            // 
            // lblsq
            // 
            this.lblsq.AutoSize = true;
            this.lblsq.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblsq.Location = new System.Drawing.Point(736, 587);
            this.lblsq.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblsq.Name = "lblsq";
            this.lblsq.Size = new System.Drawing.Size(0, 22);
            this.lblsq.TabIndex = 49;
            this.lblsq.Click += new System.EventHandler(this.lblsq_Click);
            // 
            // lblcc
            // 
            this.lblcc.AutoSize = true;
            this.lblcc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcc.Location = new System.Drawing.Point(736, 554);
            this.lblcc.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblcc.Name = "lblcc";
            this.lblcc.Size = new System.Drawing.Size(0, 22);
            this.lblcc.TabIndex = 48;
            this.lblcc.Click += new System.EventHandler(this.lblcc_Click);
            // 
            // lblp
            // 
            this.lblp.AutoSize = true;
            this.lblp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblp.Location = new System.Drawing.Point(736, 522);
            this.lblp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblp.Name = "lblp";
            this.lblp.Size = new System.Drawing.Size(0, 22);
            this.lblp.TabIndex = 47;
            this.lblp.Click += new System.EventHandler(this.lblp_Click);
            // 
            // lblpersee
            // 
            this.lblpersee.AutoSize = true;
            this.lblpersee.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpersee.Location = new System.Drawing.Point(854, 682);
            this.lblpersee.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpersee.Name = "lblpersee";
            this.lblpersee.Size = new System.Drawing.Size(0, 22);
            this.lblpersee.TabIndex = 58;
            this.lblpersee.Click += new System.EventHandler(this.lblpersee_Click);
            // 
            // lblperse
            // 
            this.lblperse.AutoSize = true;
            this.lblperse.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblperse.Location = new System.Drawing.Point(854, 650);
            this.lblperse.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblperse.Name = "lblperse";
            this.lblperse.Size = new System.Drawing.Size(0, 22);
            this.lblperse.TabIndex = 57;
            this.lblperse.Click += new System.EventHandler(this.lblperse_Click);
            // 
            // lblpersp
            // 
            this.lblpersp.AutoSize = true;
            this.lblpersp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpersp.Location = new System.Drawing.Point(854, 617);
            this.lblpersp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpersp.Name = "lblpersp";
            this.lblpersp.Size = new System.Drawing.Size(0, 22);
            this.lblpersp.TabIndex = 56;
            this.lblpersp.Click += new System.EventHandler(this.lblpersp_Click);
            // 
            // lblpersq
            // 
            this.lblpersq.AutoSize = true;
            this.lblpersq.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpersq.Location = new System.Drawing.Point(854, 587);
            this.lblpersq.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpersq.Name = "lblpersq";
            this.lblpersq.Size = new System.Drawing.Size(0, 22);
            this.lblpersq.TabIndex = 55;
            this.lblpersq.Click += new System.EventHandler(this.lblpersq_Click);
            // 
            // lblpercc
            // 
            this.lblpercc.AutoSize = true;
            this.lblpercc.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpercc.Location = new System.Drawing.Point(854, 554);
            this.lblpercc.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpercc.Name = "lblpercc";
            this.lblpercc.Size = new System.Drawing.Size(0, 22);
            this.lblpercc.TabIndex = 54;
            this.lblpercc.Click += new System.EventHandler(this.lblpercc_Click);
            // 
            // lblperp
            // 
            this.lblperp.AutoSize = true;
            this.lblperp.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblperp.Location = new System.Drawing.Point(854, 522);
            this.lblperp.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblperp.Name = "lblperp";
            this.lblperp.Size = new System.Drawing.Size(0, 22);
            this.lblperp.TabIndex = 53;
            this.lblperp.Click += new System.EventHandler(this.lblperp_Click);
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label49.Location = new System.Drawing.Point(150, 763);
            this.label49.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(258, 22);
            this.label49.TabIndex = 59;
            this.label49.Text = "Grade Point Average (GPA)";
            // 
            // lblgpa
            // 
            this.lblgpa.AutoSize = true;
            this.lblgpa.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgpa.Location = new System.Drawing.Point(457, 763);
            this.lblgpa.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblgpa.Name = "lblgpa";
            this.lblgpa.Size = new System.Drawing.Size(0, 22);
            this.lblgpa.TabIndex = 60;
            this.lblgpa.Click += new System.EventHandler(this.label50_Click);
            // 
            // lblpertotal
            // 
            this.lblpertotal.AutoSize = true;
            this.lblpertotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpertotal.Location = new System.Drawing.Point(607, 718);
            this.lblpertotal.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpertotal.Name = "lblpertotal";
            this.lblpertotal.Size = new System.Drawing.Size(0, 22);
            this.lblpertotal.TabIndex = 61;
            this.lblpertotal.Click += new System.EventHandler(this.label51_Click);
            // 
            // lblgrade
            // 
            this.lblgrade.AutoSize = true;
            this.lblgrade.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblgrade.Location = new System.Drawing.Point(736, 718);
            this.lblgrade.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblgrade.Name = "lblgrade";
            this.lblgrade.Size = new System.Drawing.Size(0, 22);
            this.lblgrade.TabIndex = 62;
            this.lblgrade.Click += new System.EventHandler(this.label52_Click);
            // 
            // lblpercentage
            // 
            this.lblpercentage.AutoSize = true;
            this.lblpercentage.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpercentage.Location = new System.Drawing.Point(854, 718);
            this.lblpercentage.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.lblpercentage.Name = "lblpercentage";
            this.lblpercentage.Size = new System.Drawing.Size(0, 22);
            this.lblpercentage.TabIndex = 63;
            this.lblpercentage.Click += new System.EventHandler(this.label53_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(858, 753);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(119, 32);
            this.button1.TabIndex = 64;
            this.button1.Text = "Resut";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 23F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 872);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblpercentage);
            this.Controls.Add(this.lblgrade);
            this.Controls.Add(this.lblpertotal);
            this.Controls.Add(this.lblgpa);
            this.Controls.Add(this.label49);
            this.Controls.Add(this.lblpersee);
            this.Controls.Add(this.lblperse);
            this.Controls.Add(this.lblpersp);
            this.Controls.Add(this.lblpersq);
            this.Controls.Add(this.lblpercc);
            this.Controls.Add(this.lblperp);
            this.Controls.Add(this.lblsee);
            this.Controls.Add(this.lblse);
            this.Controls.Add(this.lblsp);
            this.Controls.Add(this.lblsq);
            this.Controls.Add(this.lblcc);
            this.Controls.Add(this.lblp);
            this.Controls.Add(this.lbltotal);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.txtsee);
            this.Controls.Add(this.txtse);
            this.Controls.Add(this.txtsp);
            this.Controls.Add(this.txtsq);
            this.Controls.Add(this.txtcc);
            this.Controls.Add(this.txtp);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.textBox5);
            this.Controls.Add(this.textBox6);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.TextBox txtp;
        private System.Windows.Forms.TextBox txtcc;
        private System.Windows.Forms.TextBox txtsq;
        private System.Windows.Forms.TextBox txtsp;
        private System.Windows.Forms.TextBox txtse;
        private System.Windows.Forms.TextBox txtsee;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label lbltotal;
        private System.Windows.Forms.Label lblsee;
        private System.Windows.Forms.Label lblse;
        private System.Windows.Forms.Label lblsp;
        private System.Windows.Forms.Label lblsq;
        private System.Windows.Forms.Label lblcc;
        private System.Windows.Forms.Label lblp;
        private System.Windows.Forms.Label lblpersee;
        private System.Windows.Forms.Label lblperse;
        private System.Windows.Forms.Label lblpersp;
        private System.Windows.Forms.Label lblpersq;
        private System.Windows.Forms.Label lblpercc;
        private System.Windows.Forms.Label lblperp;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label lblgpa;
        private System.Windows.Forms.Label lblpertotal;
        private System.Windows.Forms.Label lblgrade;
        private System.Windows.Forms.Label lblpercentage;
        private System.Windows.Forms.Button button1;
    }
}

